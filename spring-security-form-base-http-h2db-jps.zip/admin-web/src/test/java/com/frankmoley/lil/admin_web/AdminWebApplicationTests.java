package com.frankmoley.lil.admin_web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
