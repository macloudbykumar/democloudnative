package com.example.integrationdemo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.channel.QueueChannel;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.GenericMessage;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class IntegrationFlowTest {

    @Autowired
    private org.springframework.messaging.MessageChannel inputChannel;

    @Autowired
    private QueueChannel outputChannel;

    @Test
    public void testIntegrationFlow() {
        inputChannel.send(new GenericMessage<>("test message"));

        Message<?> reply = outputChannel.receive(0);
        assertThat(reply).isNotNull();
        assertThat(reply.getPayload()).isEqualTo("TEST MESSAGE"); // depending on your transform logic
    }
}
