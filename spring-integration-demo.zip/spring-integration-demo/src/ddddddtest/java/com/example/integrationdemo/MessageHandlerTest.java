package com.example.integrationdemo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.handler.GenericHandler;
import org.springframework.messaging.Message;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class MessageHandlerTest {

    @Autowired
    private GenericHandler<String> myMessageHandler;

    @Test
    public void testMessageHandler() {
        Message<String> message = org.springframework.messaging.support.MessageBuilder.withPayload("hello").build();
        Object result = myMessageHandler.handle(message.getPayload(), message.getHeaders());
        assertThat(result).isEqualTo("ExpectedResult"); // customize as per your handler logic
    }
}
