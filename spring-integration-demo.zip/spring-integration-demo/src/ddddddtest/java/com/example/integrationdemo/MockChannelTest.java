package com.example.integrationdemo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.integration.test.context.SpringIntegrationTest;
import org.springframework.integration.test.mock.MockIntegrationContext;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.GenericMessage;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@SpringIntegrationTest
public class MockChannelTest {

    @Autowired
    private MockIntegrationContext mockIntegrationContext;

    @Autowired
    private MessageChannel inputChannel;

    @Test
    public void testWithMockChannel() {
        MessageChannel mockChannel = mockIntegrationContext.substituteMessageChannel("externalChannel");

        // Send test message to mock channel and verify behavior
        mockChannel.send(new GenericMessage<>("mock test"));

        // Add your assertions here, e.g., verify message received, mock behavior etc.
        assertThat(mockChannel).isNotNull();
    }
}
