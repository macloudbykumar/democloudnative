package com.example.integrationdemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class IntegrationController {

    @Autowired
    private MessageChannel inputChannel;

    @GetMapping("/sendMessage")
    public String sendMessage(@RequestParam String message) {
        Message<String> msg = MessageBuilder.withPayload(message).build();
        inputChannel.send(msg);
        return "Message sent: " + message;
    }
}
