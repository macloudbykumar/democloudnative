package com.example.integrationdemo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.IntegrationComponentScan;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.MessageChannels;
import org.springframework.messaging.MessageChannel;

@Configuration
@IntegrationComponentScan
public class IntegrationConfig {

    @Bean
    public MessageChannel inputChannel() {
        return MessageChannels.direct().get();
    }

    // You can remove this if not explicitly needed elsewhere
    @Bean
    public MessageChannel outputChannel() {
        return MessageChannels.direct().get();
    }

    @Bean
    public IntegrationFlow integrationFlow() {
        return IntegrationFlows.from(inputChannel())
                .transform((String s) -> s.toUpperCase())
                .handle(message -> System.out.println("Processed Message: " + message.getPayload()))
                .get();
    }
}
